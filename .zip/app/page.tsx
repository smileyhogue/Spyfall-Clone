import ClientHome from './components/ClientHome';

export default function Home() {
  return <ClientHome />;
}